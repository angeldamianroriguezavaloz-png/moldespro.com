import { useState, useEffect, useRef } from "react";

const HOTMART_URL = "https://go.hotmart.com/W107716731Q?ap=51bc";

const reviews = [
  {
    name: "María González",
    location: "Ciudad de México, MX",
    stars: 5,
    text: "¡Increíbles moldes! Nunca había cosido algo tan bien terminado. Las instrucciones son súper claras y las tallas están perfectamente detalladas. Ya hice 3 vestidos y todos me quedaron espectaculares.",
    date: "hace 2 semanas",
    avatar: "MG",
    color: "bg-rose-400",
    product: "Colección Vestidos",
  },
  {
    name: "Sofía Ramírez",
    location: "Buenos Aires, AR",
    stars: 5,
    text: "Llevaba años buscando moldes profesionales de verdad. Estos son de una calidad impresionante. Las medidas son exactas y los acabados quedan como de boutique. 100% recomendados.",
    date: "hace 1 mes",
    avatar: "SR",
    color: "bg-purple-400",
    product: "Colección Completa",
  },
  {
    name: "Valentina Torres",
    location: "Bogotá, CO",
    stars: 5,
    text: "Compré con desconfianza porque nunca había comprado moldes digitales, pero fue la mejor decisión. Descargué al instante y los patrones son profesionales. Mi clientas me preguntan dónde compro la ropa.",
    date: "hace 3 semanas",
    avatar: "VT",
    color: "bg-amber-400",
    product: "Blusas & Tops",
  },
  {
    name: "Carmen Vidal",
    location: "Lima, PE",
    stars: 5,
    text: "Soy modista profesional y estos moldes me ahorraron muchísimo tiempo. El nivel de detalle es extraordinario, cada pieza viene con las marcas exactas. ¡Son mi secreto mejor guardado!",
    date: "hace 5 días",
    avatar: "CV",
    color: "bg-teal-400",
    product: "Colección Completa",
  },
  {
    name: "Lucía Mendez",
    location: "Santiago, CL",
    stars: 5,
    text: "Lo mejor que he comprado para mi taller. Hice pantalones, faldas y blusas con estos moldes y todo quedó perfecto. El soporte también es excelente, resolvieron todas mis dudas.",
    date: "hace 2 meses",
    avatar: "LM",
    color: "bg-blue-400",
    product: "Pantalones & Faldas",
  },
  {
    name: "Isabella Fuentes",
    location: "Caracas, VE",
    stars: 5,
    text: "No puedo creer el valor que tienen estos moldes por ese precio. Son dignos de una escuela de diseño. Mi hija aprendió a coser con ellos y ya está haciendo su propio guardarropa.",
    date: "hace 1 semana",
    avatar: "IF",
    color: "bg-pink-400",
    product: "Colección Vestidos",
  },
];

const faqs = [
  {
    q: "¿En qué formato recibo los moldes?",
    a: "Recibirás los moldes en formato PDF de alta resolución, listos para imprimir en casa o en cualquier papelería. También incluimos versión digital para usar directamente en pantalla.",
  },
  {
    q: "¿Qué tallas están incluidas?",
    a: "La colección incluye tallas desde XS hasta 3XL (del 32 al 58), con instrucciones para hacer ajustes personalizados según tus medidas exactas.",
  },
  {
    q: "¿Necesito experiencia previa en costura?",
    a: "¡No! Los moldes vienen con instrucciones paso a paso ideales tanto para principiantes como para modistas con experiencia. Incluimos guías de corte, marcas y armado.",
  },
  {
    q: "¿Cuánto tiempo tarda en llegar mi compra?",
    a: "Es una compra digital, así que el acceso es inmediato. En minutos de completar el pago recibirás el enlace de descarga en tu correo electrónico.",
  },
  {
    q: "¿Puedo usar los moldes comercialmente?",
    a: "¡Sí! Puedes usar los moldes para confeccionar y vender prendas. No puedes revender los moldes como tal, pero las prendas que crees son tuyas.",
  },
  {
    q: "¿Tienen garantía?",
    a: "Sí, ofrecemos garantía de satisfacción de 7 días. Si no estás 100% satisfecha con tu compra, te devolvemos el dinero sin preguntas.",
  },
];

function StarRating({ count = 5 }: { count?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <svg key={i} className="w-4 h-4 text-amber-400 fill-amber-400" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

function CountdownTimer() {
  const [time, setTime] = useState({ hours: 3, minutes: 47, seconds: 22 });

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prev) => {
        let { hours, minutes, seconds } = prev;
        if (seconds > 0) return { hours, minutes, seconds: seconds - 1 };
        if (minutes > 0) return { hours, minutes: minutes - 1, seconds: 59 };
        if (hours > 0) return { hours: hours - 1, minutes: 59, seconds: 59 };
        return { hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div className="flex items-center gap-2 justify-center">
      {[
        { label: "Horas", value: time.hours },
        { label: "Min", value: time.minutes },
        { label: "Seg", value: time.seconds },
      ].map(({ label, value }, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="bg-white text-rose-600 rounded-lg px-3 py-2 text-center min-w-[60px]">
            <div className="text-2xl font-bold leading-none">{pad(value)}</div>
            <div className="text-xs text-gray-500 mt-1">{label}</div>
          </div>
          {i < 2 && <span className="text-white text-2xl font-bold">:</span>}
        </div>
      ))}
    </div>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className="border border-rose-100 rounded-xl overflow-hidden cursor-pointer"
      onClick={() => setOpen(!open)}
    >
      <div className="flex items-center justify-between p-5 bg-white hover:bg-rose-50 transition-colors">
        <span className="font-semibold text-gray-800 text-left pr-4">{q}</span>
        <span
          className={`text-rose-500 text-xl font-bold transition-transform duration-300 flex-shrink-0 ${
            open ? "rotate-45" : ""
          }`}
        >
          +
        </span>
      </div>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          open ? "max-h-48" : "max-h-0"
        }`}
      >
        <div className="p-5 bg-rose-50 text-gray-600 leading-relaxed border-t border-rose-100">
          {a}
        </div>
      </div>
    </div>
  );
}

function ReviewCard({ review }: { review: (typeof reviews)[0] }) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100 flex flex-col gap-4 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-full ${review.color} flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}
          >
            {review.avatar}
          </div>
          <div>
            <div className="font-semibold text-gray-800">{review.name}</div>
            <div className="text-xs text-gray-400">{review.location}</div>
          </div>
        </div>
        <span className="text-xs text-gray-400 whitespace-nowrap">{review.date}</span>
      </div>
      <StarRating />
      <p className="text-gray-600 text-sm leading-relaxed">"{review.text}"</p>
      <div className="mt-auto">
        <span className="inline-block bg-rose-50 text-rose-600 text-xs font-medium px-3 py-1 rounded-full">
          ✓ Compra verificada · {review.product}
        </span>
      </div>
    </div>
  );
}

export default function App() {
  const [visibleSection, setVisibleSection] = useState<string[]>([]);
  const sectionRefs = useRef<{ [key: string]: HTMLElement | null }>({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute("data-section");
            if (id) setVisibleSection((prev) => [...new Set([...prev, id])]);
          }
        });
      },
      { threshold: 0.1 }
    );

    Object.values(sectionRefs.current).forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const setRef = (id: string) => (el: HTMLElement | null) => {
    sectionRefs.current[id] = el;
  };

  const isVisible = (id: string) => visibleSection.includes(id);

  return (
    <div className="font-inter bg-white overflow-x-hidden">
      {/* Sticky Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">✂️</span>
            <span className="font-playfair font-bold text-gray-800 text-lg">
              Moldes<span className="text-rose-500">Pro</span>
            </span>
          </div>
          <a
            href={HOTMART_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-rose-500 hover:bg-rose-600 text-white font-semibold px-5 py-2 rounded-full text-sm transition-all hover:scale-105 shadow-md"
          >
            ¡Quiero mis Moldes!
          </a>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.pexels.com/photos/8483986/pexels-photo-8483986.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-rose-900/85 via-rose-800/75 to-pink-900/80" />

        {/* Decorative elements */}
        <div className="absolute top-20 right-10 w-72 h-72 bg-rose-400/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-pink-400/20 rounded-full blur-3xl" />

        <div className="relative z-10 max-w-6xl mx-auto px-4 py-20 grid lg:grid-cols-2 gap-12 items-center w-full">
          <div className="text-white space-y-6">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/30 rounded-full px-4 py-2 text-sm font-medium">
              <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
              🔥 +2,000 costureras ya lo tienen
            </div>

            <h1
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight"
              style={{ fontFamily: "Playfair Display, serif" }}
            >
              Crea Ropa{" "}
              <span className="text-amber-300 italic">Profesional</span>{" "}
              con Moldes Exactos
            </h1>

            <p className="text-lg text-white/85 leading-relaxed">
              Accede a nuestra colección completa de <strong>moldes de costura digitales</strong> con tallas desde XS hasta 3XL. Instrucciones claras, medidas exactas y resultados de boutique — ¡desde casa!
            </p>

            {/* Stars + Social proof */}
            <div className="flex items-center gap-3">
              <StarRating count={5} />
              <span className="text-white/90 text-sm">
                <strong>4.9/5</strong> · Más de 2,000 reseñas
              </span>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href={HOTMART_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-amber-400 hover:bg-amber-300 text-gray-900 font-bold px-8 py-4 rounded-2xl text-lg transition-all hover:scale-105 shadow-xl shadow-amber-500/30 text-center flex items-center justify-center gap-2"
              >
                🛒 Comprar Ahora
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </a>
              <a
                href="#moldes"
                className="border-2 border-white/50 text-white hover:bg-white/10 font-semibold px-8 py-4 rounded-2xl text-lg transition-all text-center"
              >
                Ver Moldes
              </a>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-4 text-white/80 text-sm">
              <span className="flex items-center gap-1.5">
                <span className="text-green-400">✓</span> Descarga Inmediata
              </span>
              <span className="flex items-center gap-1.5">
                <span className="text-green-400">✓</span> Garantía 7 días
              </span>
              <span className="flex items-center gap-1.5">
                <span className="text-green-400">✓</span> Pago Seguro
              </span>
            </div>
          </div>

          {/* Right card */}
          <div className="hidden lg:block">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-8 space-y-6">
              <div className="bg-white rounded-2xl p-6 shadow-xl">
                <div className="text-center space-y-2 mb-4">
                  <div className="text-gray-400 text-sm line-through">Precio normal: $97</div>
                  <div className="text-5xl font-bold text-rose-500">$37</div>
                  <div className="text-gray-500 text-sm">Oferta por tiempo limitado</div>
                </div>
                <div className="bg-rose-50 rounded-xl p-3 mb-4">
                  <CountdownTimer />
                  <p className="text-center text-rose-600 text-xs mt-2 font-medium">⏳ La oferta expira pronto</p>
                </div>
                <a
                  href={HOTMART_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full bg-rose-500 hover:bg-rose-600 text-white font-bold py-4 rounded-xl text-center transition-all hover:scale-105 shadow-lg"
                >
                  ¡Obtener Acceso Ahora!
                </a>
                <div className="flex flex-col items-center gap-1 mt-3">
                  <div className="flex items-center gap-2 text-gray-400 text-xs">
                    <span>🔒</span>
                    <span>Pago 100% seguro con Hotmart</span>
                  </div>
                  <span className="text-rose-400 font-mono text-xs font-semibold">cosetusropas.com/coleccion</span>
                </div>
              </div>
              <div className="space-y-3 text-white/90 text-sm">
                {[
                  "✂️ +50 moldes de diferentes prendas",
                  "📐 Tallas XS a 3XL incluidas",
                  "📱 Acceso digital de por vida",
                  "🎓 Guías de armado incluidas",
                  "💬 Soporte personalizado",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2">
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Bar */}
      <section className="bg-rose-500 text-white py-4">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-6 md:gap-12 text-center text-sm font-medium">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">2,000+</span>
              <span className="text-white/80">Clientas felices</span>
            </div>
            <div className="hidden md:block w-px bg-white/30" />
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">4.9★</span>
              <span className="text-white/80">Calificación promedio</span>
            </div>
            <div className="hidden md:block w-px bg-white/30" />
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">50+</span>
              <span className="text-white/80">Modelos de moldes</span>
            </div>
            <div className="hidden md:block w-px bg-white/30" />
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">7 días</span>
              <span className="text-white/80">Garantía total</span>
            </div>
          </div>
        </div>
      </section>

      {/* WHAT'S INCLUDED */}
      <section
        id="moldes"
        ref={setRef("moldes")}
        data-section="moldes"
        className={`py-20 bg-gray-50 transition-all duration-700 ${
          isVisible("moldes") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="bg-rose-100 text-rose-600 text-sm font-semibold px-4 py-1.5 rounded-full">
              ¿Qué incluye?
            </span>
            <h2
              className="text-3xl md:text-4xl font-bold text-gray-800 mt-4 mb-4"
              style={{ fontFamily: "Playfair Display, serif" }}
            >
              Todo lo que necesitas para crear ropa increíble
            </h2>
            <p className="text-gray-500 max-w-xl mx-auto">
              Una colección completa y profesional lista para imprimir y usar de inmediato.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: "👗",
                title: "Vestidos & Faldas",
                desc: "Desde vestidos casuales hasta elegantes. Incluye faldas de distintos largos y cortes.",
                count: "+15 moldes",
              },
              {
                icon: "👚",
                title: "Blusas & Tops",
                desc: "Escotes variados, mangas largas y cortas, con y sin entalle. Para todos los estilos.",
                count: "+12 moldes",
              },
              {
                icon: "👖",
                title: "Pantalones & Shorts",
                desc: "Pantalones rectos, acampanados, cargo y shorts en diferentes largos.",
                count: "+10 moldes",
              },
              {
                icon: "🧥",
                title: "Chaquetas & Abrigos",
                desc: "Desde blazers estructurados hasta abrigos de invierno. Perfectos para cualquier temporada.",
                count: "+8 moldes",
              },
              {
                icon: "📐",
                title: "Tallas XS a 3XL",
                desc: "Todas las prendas vienen en tallas completas con instrucciones de ajuste personalizado.",
                count: "Todas las tallas",
              },
              {
                icon: "📖",
                title: "Guías de Armado",
                desc: "Instrucciones paso a paso con fotos y explicaciones claras para cada prenda.",
                count: "Guía completa",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md hover:border-rose-200 transition-all group"
              >
                <div className="text-4xl mb-4">{item.icon}</div>
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-bold text-gray-800 text-lg">{item.title}</h3>
                  <span className="bg-rose-100 text-rose-600 text-xs font-semibold px-2 py-1 rounded-full flex-shrink-0 ml-2">
                    {item.count}
                  </span>
                </div>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section
        ref={setRef("steps")}
        data-section="steps"
        className={`py-20 bg-white transition-all duration-700 delay-100 ${
          isVisible("steps") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="bg-rose-100 text-rose-600 text-sm font-semibold px-4 py-1.5 rounded-full">
              Así de fácil
            </span>
            <h2
              className="text-3xl md:text-4xl font-bold text-gray-800 mt-4"
              style={{ fontFamily: "Playfair Display, serif" }}
            >
              Empieza a coser en 3 pasos
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8 relative">
            <div className="hidden md:block absolute top-12 left-1/4 right-1/4 h-0.5 bg-rose-200" />
            {[
              {
                step: "01",
                icon: "🛒",
                title: "Compra tu colección",
                desc: "Haz click en el botón y completa tu pago de forma segura en Hotmart. Tarda menos de 2 minutos.",
              },
              {
                step: "02",
                icon: "📥",
                title: "Descarga al instante",
                desc: "Recibe el enlace de descarga en tu correo al momento. Todos los archivos PDF listos para usar.",
              },
              {
                step: "03",
                icon: "✂️",
                title: "¡Empieza a crear!",
                desc: "Imprime, corta y cose siguiendo nuestras guías. En poco tiempo tendrás prendas profesionales.",
              },
            ].map((step) => (
              <div key={step.step} className="text-center space-y-4 relative">
                <div className="relative inline-flex">
                  <div className="w-24 h-24 bg-rose-50 rounded-full flex items-center justify-center text-4xl mx-auto border-4 border-white shadow-md">
                    {step.icon}
                  </div>
                  <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-xs font-bold w-7 h-7 rounded-full flex items-center justify-center">
                    {step.step}
                  </span>
                </div>
                <h3 className="font-bold text-gray-800 text-lg">{step.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PREVIEW IMAGE */}
      <section className="py-16 bg-gradient-to-r from-rose-50 to-pink-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/7776108/pexels-photo-7776108.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800"
                alt="Moldes de costura profesionales"
                className="rounded-3xl shadow-2xl w-full object-cover h-80 lg:h-96"
              />
            </div>
            <div className="space-y-6">
              <span className="bg-rose-100 text-rose-600 text-sm font-semibold px-4 py-1.5 rounded-full">
                Calidad garantizada
              </span>
              <h2
                className="text-3xl md:text-4xl font-bold text-gray-800"
                style={{ fontFamily: "Playfair Display, serif" }}
              >
                Moldes diseñados por <span className="text-rose-500 italic">profesionales</span> para ti
              </h2>
              <p className="text-gray-600 leading-relaxed">
                Cada molde fue creado por diseñadoras de moda con años de experiencia en la industria. Medidas perfectas, marcas claras y cortes precisos para que tus prendas queden impecables.
              </p>
              <div className="space-y-3">
                {[
                  "Líneas de costura y margen de costura marcadas",
                  "Puntos de control para alineación perfecta",
                  "Guías de corte en tela según tipo de tejido",
                  "Instrucciones de planchado y acabados",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-rose-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-gray-700 text-sm">{item}</span>
                  </div>
                ))}
              </div>
              <a
                href={HOTMART_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-rose-500 hover:bg-rose-600 text-white font-bold px-8 py-4 rounded-2xl transition-all hover:scale-105 shadow-lg"
              >
                Quiero mis moldes ahora →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section
        ref={setRef("reviews")}
        data-section="reviews"
        className={`py-20 bg-white transition-all duration-700 ${
          isVisible("reviews") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="bg-amber-100 text-amber-600 text-sm font-semibold px-4 py-1.5 rounded-full">
              ⭐ Reseñas reales
            </span>
            <h2
              className="text-3xl md:text-4xl font-bold text-gray-800 mt-4 mb-4"
              style={{ fontFamily: "Playfair Display, serif" }}
            >
              Lo que dicen nuestras clientas
            </h2>
            <div className="flex items-center justify-center gap-3">
              <StarRating count={5} />
              <span className="text-gray-600 font-semibold">4.9 de 5</span>
              <span className="text-gray-400">·</span>
              <span className="text-gray-500 text-sm">Basado en +2,000 compras verificadas</span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review) => (
              <ReviewCard key={review.name} review={review} />
            ))}
          </div>

          {/* Trust badges */}
          <div className="mt-12 flex flex-wrap justify-center gap-6">
            {[
              { icon: "🔒", label: "Compra Segura", sub: "Cifrado SSL 256 bits" },
              { icon: "💳", label: "Múltiples Pagos", sub: "Tarjeta, PIX, PayPal" },
              { icon: "📧", label: "Soporte 24/7", sub: "Respuesta en < 24 hrs" },
              { icon: "↩️", label: "Garantía 7 días", sub: "Devolución sin preguntas" },
            ].map((badge) => (
              <div
                key={badge.label}
                className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-xl px-5 py-4 min-w-[180px]"
              >
                <span className="text-2xl">{badge.icon}</span>
                <div>
                  <div className="font-semibold text-gray-800 text-sm">{badge.label}</div>
                  <div className="text-gray-500 text-xs">{badge.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING CTA */}
      <section
        ref={setRef("pricing")}
        data-section="pricing"
        className={`py-20 bg-gradient-to-br from-rose-500 via-rose-600 to-pink-700 transition-all duration-700 ${
          isVisible("pricing") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="max-w-4xl mx-auto px-4 text-center">
          <span className="bg-white/20 text-white text-sm font-semibold px-4 py-1.5 rounded-full border border-white/30">
            🔥 Oferta Especial — Solo por hoy
          </span>
          <h2
            className="text-3xl md:text-5xl font-bold text-white mt-6 mb-4"
            style={{ fontFamily: "Playfair Display, serif" }}
          >
            Accede a toda la colección
          </h2>
          <p className="text-white/85 text-lg mb-8 max-w-xl mx-auto">
            Más de 50 moldes profesionales, guías completas y acceso de por vida por un precio increíble.
          </p>

          <div className="bg-white rounded-3xl p-8 max-w-md mx-auto shadow-2xl mb-8">
            <div className="text-gray-400 text-lg line-through mb-1">$97.00 USD</div>
            <div className="text-6xl font-bold text-rose-500 mb-1">$37</div>
            <div className="text-gray-500 mb-2">Pago único · Acceso de por vida</div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-6">
              <p className="text-amber-700 text-sm font-medium text-center">⏰ Esta oferta expira en:</p>
              <div className="mt-2">
                <CountdownTimer />
              </div>
            </div>

            <a
              href={HOTMART_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full bg-rose-500 hover:bg-rose-600 text-white font-bold py-5 rounded-2xl text-xl transition-all hover:scale-105 shadow-lg mb-4"
            >
              🛒 COMPRAR AHORA POR $37
            </a>

            <div className="space-y-2 text-sm text-gray-500">
              <p className="flex items-center justify-center gap-2">
                <span>🔒</span> Pago 100% seguro con Hotmart
              </p>
              <p className="flex items-center justify-center gap-2">
                <span>💳</span> Tarjeta de crédito / débito / PayPal / PIX
              </p>
              <p className="flex items-center justify-center gap-2">
                <span>↩️</span> Garantía de devolución de 7 días
              </p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-white/80 text-sm">
            {[
              "✓ +50 moldes incluidos",
              "✓ Todas las tallas",
              "✓ Acceso inmediato",
              "✓ Actualizaciones gratis",
            ].map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section
        ref={setRef("faq")}
        data-section="faq"
        className={`py-20 bg-gray-50 transition-all duration-700 ${
          isVisible("faq") ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="max-w-3xl mx-auto px-4">
          <div className="text-center mb-12">
            <span className="bg-rose-100 text-rose-600 text-sm font-semibold px-4 py-1.5 rounded-full">
              FAQ
            </span>
            <h2
              className="text-3xl md:text-4xl font-bold text-gray-800 mt-4"
              style={{ fontFamily: "Playfair Display, serif" }}
            >
              Preguntas frecuentes
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq) => (
              <FAQItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>

          <div className="mt-10 bg-white rounded-2xl p-6 border border-rose-100 text-center">
            <p className="text-gray-600 mb-4">
              ¿Tienes otra pregunta? ¡Estamos aquí para ayudarte!
            </p>
            <a
              href="mailto:soporte@moldespro.com"
              className="inline-flex items-center gap-2 text-rose-500 hover:text-rose-600 font-semibold transition-colors"
            >
              📧 Contactar soporte
            </a>
          </div>
        </div>
      </section>

      {/* GUARANTEE */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-3xl p-10 flex flex-col md:flex-row items-center gap-8">
            <div className="text-center flex-shrink-0">
              <div className="w-28 h-28 bg-green-100 rounded-full flex items-center justify-center text-5xl mx-auto border-4 border-green-200">
                🛡️
              </div>
            </div>
            <div>
              <h3
                className="text-2xl font-bold text-gray-800 mb-3"
                style={{ fontFamily: "Playfair Display, serif" }}
              >
                Garantía de Satisfacción Total — 7 días
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Estamos tan seguros de la calidad de nuestros moldes que te ofrecemos una <strong>garantía de devolución de 7 días sin preguntas</strong>. Si por cualquier razón no estás 100% satisfecha, te devolvemos tu dinero completo. Sin complicaciones, sin excusas.
              </p>
              <p className="text-green-600 font-semibold mt-3">
                ✓ Tu inversión está completamente protegida
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2
            className="text-3xl md:text-4xl font-bold mb-4"
            style={{ fontFamily: "Playfair Display, serif" }}
          >
            ¿Lista para crear ropa increíble?
          </h2>
          <p className="text-gray-400 mb-8 text-lg">
            Únete a más de 2,000 mujeres que ya están creando su propio guardarropa
          </p>
          <a
            href={HOTMART_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-amber-400 hover:bg-amber-300 text-gray-900 font-bold px-10 py-5 rounded-2xl text-xl transition-all hover:scale-105 shadow-xl shadow-amber-500/20"
          >
            🛒 Obtener Moldes por $37 →
          </a>
          <p className="text-gray-500 text-sm mt-4">
            Pago seguro · Descarga inmediata · Garantía 7 días
          </p>
          <p className="text-gray-600 text-xs mt-2 font-mono">
            🔗 cosetusropas.com/coleccion
          </p>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-gray-950 text-gray-500 py-8">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xl">✂️</span>
              <span className="text-white font-bold">
                Moldes<span className="text-rose-400">Pro</span>
              </span>
            </div>
            <p className="text-xs text-center">
              © 2025 MoldesPro · Todos los derechos reservados ·{" "}
              <span className="text-rose-400 font-semibold">cosetusropas.com/coleccion</span>
            </p>
            <div className="flex gap-4 text-xs">
              <a href="#" className="hover:text-white transition-colors">Privacidad</a>
              <a href="#" className="hover:text-white transition-colors">Términos</a>
              <a href="#" className="hover:text-white transition-colors">Contacto</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating CTA button */}
      <div className="fixed bottom-6 right-6 z-50 group flex flex-col items-end gap-2">
        <div className="hidden group-hover:flex bg-gray-900 text-white text-xs px-3 py-1.5 rounded-lg shadow-lg items-center gap-1.5 whitespace-nowrap">
          <span>🔗</span>
          <span className="font-mono">cosetusropas.com/coleccion</span>
        </div>
        <a
          href={HOTMART_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-rose-500 hover:bg-rose-600 text-white font-bold px-5 py-3 rounded-full shadow-2xl shadow-rose-500/40 transition-all hover:scale-105 text-sm"
        >
          🛒 Comprar $37
        </a>
      </div>
    </div>
  );
}
